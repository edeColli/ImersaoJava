# Release Changelog

[See GitHub releases](https://github.com/dialex/JColor/releases)